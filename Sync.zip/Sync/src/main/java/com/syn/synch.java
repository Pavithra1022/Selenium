package com.syn;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.http.util.Asserts;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class synch {

	public static WebDriver driver;

	public static void main(String args[]) {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.get("https://opensource-demo.orangehrmlive.com/");

		WebElement username = driver.findElement(By.id("txtUsername"));
		WebElement password = driver.findElement(By.id("txtPassword"));
		WebElement login = driver.findElement(By.id("btnLogin"));

		// WebElement icon =
		// driver.findElement(By.id("mainMenuFirstLevelUnorderedList"));
		// WebElement title =driver.findElement(By.id("pageTitle"));

		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		sk(username, 2, "Admin");
		sk(password, 5, "admin123");
		clickon(login, 25);
		presenceofelementlocated(15);
		visibilityofallelementslocatedby(15);
		urlMatches();
        titles(5);
	}

	public static void sk(WebElement element, int timeout, String value) {
		new WebDriverWait(driver, timeout).until(ExpectedConditions.visibilityOf(element));
		element.sendKeys(value);
		System.out.println("Test1 passed");
	}

	public static void clickon(WebElement element, int timeout) {
		new WebDriverWait(driver, timeout).until(ExpectedConditions.elementToBeClickable(element));
		element.click();
		System.out.println("Test2 passed");
	}

	public static void presenceofelementlocated(int timeout) {
		WebElement a = new WebDriverWait(driver, timeout)
				.until(ExpectedConditions.presenceOfElementLocated(By.id("menu__Performance")));

		System.out.println("Test3 passed");
	}

	public static void visibilityofallelementslocatedby(int timeout) {
		WebElement icon = driver.findElement(By.id("mainMenuFirstLevelUnorderedList"));
		List<WebElement> elements = new WebDriverWait(driver, timeout)
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id("mainMenuFirstLevelUnorderedList")));
		System.out.println(elements);
		System.out.println("Test4 passed");
	}

	public static void urlMatches() {
		Boolean bool = new WebDriverWait(driver, 15)
				.until(ExpectedConditions.urlMatches("https://opensource-demo.orangehrmlive.com/index.php/dashboard"));
		System.out.println(bool);
		System.out.println("Testcase5 passed");

	}

	public static void titles(int timeout) {
		
		driver.navigate().to("https://www.facebook.com/login/");
		WebElement title = driver.findElement(By.id("pageTitle"));
		Boolean a = new WebDriverWait(driver, 10).until(ExpectedConditions.titleContains("Log in to Facebook"));
		System.out.println(a);
		System.out.println("Testcase7 passed");
		numberofwindowstobe();
		
	}

	public static void numberofwindowstobe() {
		driver.navigate().to("https://www.google.com/");
		new WebDriverWait(driver, 20).until(ExpectedConditions.numberOfWindowsToBe(1));
		System.out.println("Testcase8 passed");

	}

	public static void waitForTextToAppear(String textToAppear, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.textToBePresentInElement(element, textToAppear));
	}

}
